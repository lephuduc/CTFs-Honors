SimCity Z80 ( 83/83+ Version )



>>>>>>> Intro <<<<<<<<<<

This project started a while ago but I  finaly put the final
dot this week. So I'm releasing it for your simple pleasure
so if you have find bug/problem you want me to notice,
look up in the contact section. In this game ( if you never
had played on any other platform ) you must build and run
a city with tax/people, you build building and you see it
growth. In this game , I tried to reproduce the
ambiance of SimCity on the Super Nes ( sorry for TradeMark )
And I think I got it! If you want to know more, just look
in the AI section where I explain ( not in detail but correcly )
how the AI of Citisen works. 

>>>>> Requirements <<<

83 Version
 - Ion
 
83+ Version
 - MirageOS ( Ion works too )
 
You send it to your calc as usual and you need like 1 to 10k free
for the map. a 125x125 takes ~16k but the program will warn you 
if you miss space.

Note about 83+ User:

	If a map is archived, it will only apear on the load screen if you 
	have enough place in ram to load it.. but the change on it will
	NOT be saved. 

Not About all user:

Also, the menu can only contain 5 maps. remove the one
or archive it if you want to see the other.. ( this is a limitation
I'll remove in future version )

>>>>>> Keys <<<<<<<<<

The Keys in the menu are simple :
 - Arrow to move
 - [2nd] to validate ( except otherwise noted in the game )

In Game the key are as folowing :
 - Arrow to move the button cursor
 - [2nd] to put on the map the building currently selected
 - [Alpha] To change the building you will put on
 - [Mode] to see Information about your City
 - [X,Y,0,n] to set the AI at full speed ( I explain
 	when this key is pressed and as long it is pressed
	the AI don't bother him checking the keyboard so
	it don't waste time in it. It is faster for the
	AI but as long as you press on this key the keybord
	is'nt checked )
 - [Stat] to optain the Delay Menu

>>>>>>> [Stats] <<<<<<<<<<

I'll explain it once, so be attentive or read back my instruction.
You will have to modify these values if you want the make ( without
pressing on XTOn ) goes faster. Or to modify it to make it slower if
your number of building is now to importent for the game ( IE; the keys
lag or simply don't register )

Speed is as stated ==> The higher THE SLOWER
AI Agressivness ==> The LOWER THE SLOWER * ( but if this value is too
	high the key will simply stop to answer or don't register ( these
	detail are usefull only with a big City. My lastest was about of
	10 000 building and I have to turn down these detail. )

The values are in hex if you mind.

Last Detail about the delay:

The game was develpped for BIG map like 80x80 and over so under that normal
that the game goes realy realy fast.

>>>>>>> How the AI works or the Key to a Great City <<<<<

So this is perhaps the most difficult section to write but I'll do
my best. The key for you city growth is the R/C/I ( the bar in 
the [mode] screen ). When they are at right ( on the + side ) then
Your building will level up. Ok now how to make your building level up
you have to get them connected to a road, you need to have enough power
plant in your city.. and you need to get at least the half test, I meant
by that that you must get at least 1/2 commerce|industry for 1 residence
and the level count up ( so a R1 is'nt a R2 ). Now to control the RCI
you must play with the tax ( I don't think that is possible to get a great
city wihout playing with the tax... ) The scale of taxation is normal,
so lvl8 get you more cash but citisen hate you, and lvl1 you get no cash
but citizen love you.. So the lower the citizen are taxed .. they love you 
in reword ask their friend to come to your city so your RCI goes up,
in other hand ... if you love to tax hard..  the citisen will be angry and 
they will get out of your city so the RCI will go down.
You will have to play with all these factors in this game...

>>>>>>> History <<<<<<<<<

V.80 [ 09/01/2004 3:14PM ] " The Pi Release "
	- Initial Public Release

>>>>> Contact <<<<<

If you have Some comments/bug/anything about the game you can contact me by these
ways:

email = paxl@videotron.ca
ICQ = 106210730
AIM = paxl13
ICQ = paxl2001@hotmail.com

I hope this game will please you... Thank you for having it downloaded...

web: www.paxl.org

>> Thanks <<

- PyroMeistar <pyromeistar@thevortex.com> for the graphic
- And every people that have helped me  ( and the list would be too
	long to write there. )


Proud TiFt member -> tift.paxl.org
~ To Be or Not To Be ~ - Hamlet
~ Hell is the Other ~ - Sarte